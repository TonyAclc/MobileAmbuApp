package com.example.mobileambulance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class emergency_call extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_emergency_call);
        View root = findViewById(R.id.container_emergency_call);
        if (root != null) {
            ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        int[] callButtonIds = new int[] {
                R.id.callbtn,
                R.id.call1,
                R.id.call12,
                R.id.call3
        };

        View.OnClickListener callClickListener = v -> {
            Intent intent = new Intent(emergency_call.this, call.class);
            startActivity(intent);
        };

        for (int buttonId : callButtonIds) {
            View button = findViewById(buttonId);
            if (button != null) {
                button.setOnClickListener(callClickListener);
            }
        }
    }
}