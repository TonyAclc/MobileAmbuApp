package com.example.mobileambulance;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class super_admin_dashboard extends AppCompatActivity {

    private View Hospitals;
    private View Admins;
    private View Analytics;

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_super_admin_dashboard);

        Hospitals = findViewById(R.id.Hospitals);
        if (Hospitals != null) {
            Hospitals.setOnClickListener(v ->
                    startActivity(new Intent(this, superadmin_hospital_management.class))
            );
        }

        Admins = findViewById(R.id.Admins);
        if (Admins != null) {
            Admins.setOnClickListener(v ->
                    startActivity(new Intent(this, superadmin_user_management.class))
            );
        }

        Analytics = findViewById(R.id.Analytics);
        if (Analytics != null) {
            Analytics.setOnClickListener(v ->
                    startActivity(new Intent(this, superadmin_analytics_reports.class))
            );
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.super_admin_dashboard), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}