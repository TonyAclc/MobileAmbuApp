package com.example.mobileambulance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class find_nearby_ambulances extends AppCompatActivity {

    private ImageView image_home;
    private ImageView image_clipboard;
    private ImageView image_user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_find_nearby_ambulances);

        image_home = findViewById(R.id.image_home);
        image_home.setOnClickListener(v -> {
            Intent intent = new Intent(find_nearby_ambulances.this, home_dashboard.class);
            startActivity(intent);
        });

        image_clipboard = findViewById(R.id.image_clipboard);
        image_clipboard.setOnClickListener(v -> {
            Intent intent = new Intent(find_nearby_ambulances.this, request_history.class);
            startActivity(intent);
        });

        image_user = findViewById(R.id.image_user);
        image_user.setOnClickListener(v -> {
            Intent intent = new Intent(find_nearby_ambulances.this, user_profile.class);
            startActivity(intent);
        });

        int[] requestCardIds = new int[] {
                R.id.image_rectangle,
                R.id.image_rectangle1,
                R.id.image_rectangle2
        };

        View.OnClickListener requestCardListener = v -> {
            Intent intent = new Intent(find_nearby_ambulances.this, request_ambulance.class);
            startActivity(intent);
        };

        for (int cardId : requestCardIds) {
            View requestCard = findViewById(cardId);
            if (requestCard != null) {
                requestCard.setOnClickListener(requestCardListener);
            }
        }

        int[] callShortcutIds = new int[] {
                R.id.call1,
                R.id.call2,
                R.id.call3
        };

        View.OnClickListener callShortcutListener = v -> {
            Intent intent = new Intent(find_nearby_ambulances.this, call.class);
            startActivity(intent);
        };

        for (int callId : callShortcutIds) {
            View callShortcut = findViewById(callId);
            if (callShortcut != null) {
                callShortcut.setOnClickListener(callShortcutListener);
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.find_nearby_ambulances), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}