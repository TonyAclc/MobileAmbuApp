package com.example.mobileambulance;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class admin_request_details extends AppCompatActivity {

    public static final String EXTRA_REQUEST_ID = "request_id";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_STATUS_DETAIL = "status_detail";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_CONTACT = "contact";
    public static final String EXTRA_AGE = "age";
    public static final String EXTRA_EMERGENCY_TYPE = "emergency_type";
    public static final String EXTRA_LOCATION = "location";
    public static final String EXTRA_AMBULANCE_INFO = "ambulance_info";
    public static final String EXTRA_DRIVER = "driver";
    public static final String EXTRA_VEHICLE = "vehicle";
    public static final String EXTRA_ETA = "eta";
    public static final String EXTRA_DISTANCE = "distance";
    public static final String EXTRA_TIME_CREATED = "time_created";
    public static final String EXTRA_TIME_ASSIGNED = "time_assigned";
    public static final String EXTRA_TIME_ENROUTE = "time_enroute";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_request_details);

        TextView backBtn = findViewById(R.id.bckbtn);
        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                Intent intent = new Intent(admin_request_details.this, admin_all_request.class);
                startActivity(intent);
            });
        }

        Intent intent = getIntent();
        if (intent != null) {
            setText(findViewById(R.id.tv_request_id), intent.getStringExtra(EXTRA_REQUEST_ID));
            setText(findViewById(R.id.tv_status), intent.getStringExtra(EXTRA_STATUS));
            setText(findViewById(R.id.tv_status_detail), intent.getStringExtra(EXTRA_STATUS_DETAIL));
            setText(findViewById(R.id.tv_name), intent.getStringExtra(EXTRA_NAME));
            setText(findViewById(R.id.tv_contact_value), intent.getStringExtra(EXTRA_CONTACT));
            setText(findViewById(R.id.tv_age), intent.getStringExtra(EXTRA_AGE));
            setText(findViewById(R.id.tv_emergency_type), intent.getStringExtra(EXTRA_EMERGENCY_TYPE));
            setText(findViewById(R.id.tv_location), intent.getStringExtra(EXTRA_LOCATION));
            setText(findViewById(R.id.tv_ambulance_info), intent.getStringExtra(EXTRA_AMBULANCE_INFO));
            setText(findViewById(R.id.tv_driver), intent.getStringExtra(EXTRA_DRIVER));
            setText(findViewById(R.id.tv_vehicle), intent.getStringExtra(EXTRA_VEHICLE));
            setText(findViewById(R.id.tv_eta), intent.getStringExtra(EXTRA_ETA));
            setText(findViewById(R.id.tv_distance), intent.getStringExtra(EXTRA_DISTANCE));
            setText(findViewById(R.id.tv_time_created_value), intent.getStringExtra(EXTRA_TIME_CREATED));
            setText(findViewById(R.id.tv_time_assigned_value), intent.getStringExtra(EXTRA_TIME_ASSIGNED));
            setText(findViewById(R.id.tv_time_enroute_value), intent.getStringExtra(EXTRA_TIME_ENROUTE));
        }

        View root = findViewById(R.id.main);
        if (root != null) {
            ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
    }

    private void setText(TextView view, String value) {
        if (view == null || TextUtils.isEmpty(value)) return;
        view.setText(value);
    }
}