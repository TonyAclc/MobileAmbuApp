package com.example.mobileambulance;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class admin_ambulance_management extends AppCompatActivity {

    private TextView Analytics;
    private TextView Dashboard;
    private TextView Requests;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_ambulance_management);

        Analytics = findViewById(R.id.Analytics);
        Analytics.setOnClickListener(view -> {
            Intent intent = new Intent(this, admin_analytics_and_reports.class);
            startActivity(intent);
        });

        Dashboard = findViewById(R.id.Dashboard);
        Dashboard.setOnClickListener(view -> {
            Intent intent = new Intent(this, admin_dashboard_overview.class);
            startActivity(intent);
        });

        Requests = findViewById(R.id.Requests);
        Requests.setOnClickListener(view -> {
            Intent intent = new Intent(this, admin_all_request.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.admin_ambulance_management), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}