package com.example.mobileambulance;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class admin_all_request extends AppCompatActivity {

    private TextView Dashboard;
    private TextView Ambulance;
    private TextView Analytics;
    private TextView Count;
    private TextView BackBtn;
    private View RequestDetails;
    private View RequestDetails2;
    private View RequestDetails3;
    private View RequestDetails4;
    private View RequestDetails5;

    private static class RequestData {
        final String requestId;
        final String status;
        final String statusDetail;
        final String name;
        final String contact;
        final String age;
        final String emergencyType;
        final String location;
        final String ambulanceInfo;
        final String driver;
        final String vehicle;
        final String eta;
        final String distance;
        final String timeCreated;
        final String timeAssigned;
        final String timeEnroute;

        RequestData(String requestId, String status, String statusDetail, String name, String contact,
                    String age, String emergencyType, String location, String ambulanceInfo,
                    String driver, String vehicle, String eta, String distance,
                    String timeCreated, String timeAssigned, String timeEnroute) {
            this.requestId = requestId;
            this.status = status;
            this.statusDetail = statusDetail;
            this.name = name;
            this.contact = contact;
            this.age = age;
            this.emergencyType = emergencyType;
            this.location = location;
            this.ambulanceInfo = ambulanceInfo;
            this.driver = driver;
            this.vehicle = vehicle;
            this.eta = eta;
            this.distance = distance;
            this.timeCreated = timeCreated;
            this.timeAssigned = timeAssigned;
            this.timeEnroute = timeEnroute;
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_all_request);

        BackBtn = findViewById(R.id.bckbtn);
        BackBtn.setOnClickListener(v -> {
            Intent intent = new Intent(admin_all_request.this, admin_dashboard_overview.class);
            startActivity(intent);
        });

        Map<Integer, RequestData> requestMap = buildRequestData();
        Count = findViewById(R.id.count);
        Count.setText("All (" + requestMap.size() + ")");

        RequestDetails = findViewById(R.id.request_details);
        setRequestClick(RequestDetails, requestMap.get(R.id.request_details));

        RequestDetails2 = findViewById(R.id.request_details_2);
        setRequestClick(RequestDetails2, requestMap.get(R.id.request_details_2));

        RequestDetails3 = findViewById(R.id.request_details_3);
        setRequestClick(RequestDetails3, requestMap.get(R.id.request_details_3));

        RequestDetails4 = findViewById(R.id.request_details_4);
        setRequestClick(RequestDetails4, requestMap.get(R.id.request_details_4));

        RequestDetails5 = findViewById(R.id.request_details_5);
        setRequestClick(RequestDetails5, requestMap.get(R.id.request_details_5));

        Dashboard = findViewById(R.id.Dashboard);
        Dashboard.setOnClickListener(v -> {
            Intent intent = new Intent(admin_all_request.this, admin_dashboard_overview.class);
            startActivity(intent);
        });

        Ambulance = findViewById(R.id.Ambulance);
        Ambulance.setOnClickListener(v -> {
            Intent intent = new Intent(admin_all_request.this, admin_ambulance_management.class);
            startActivity(intent);
        });

        Analytics = findViewById(R.id.Analytics);
        Analytics.setOnClickListener(v -> {
            Intent intent = new Intent(admin_all_request.this, admin_analytics_and_reports.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.admin_all_request), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private Map<Integer, RequestData> buildRequestData() {
        Map<Integer, RequestData> map = new HashMap<>();
        map.put(R.id.request_details, new RequestData(
                "#AMB12345", "Active Emergency", "Ambulance is en route to location",
                "Jo Dee", "+1 234 567 8901", "45 years", "Accident",
                " 123 Main Street, City Center",
                "City Hospital Ambulance (AMB-001)",
                "Driver: Mike Johnson", "Driver: AB-123",
                "ETA: 5 minutes", "Distance: 2.5 km",
                "Today at 2:30 PM", "Today at 2:31 PM", "Today at 2:32 PM - Current"
        ));
        map.put(R.id.request_details_2, new RequestData(
                "#AMB12344", "En Route", "Ambulance dispatched",
                "Jane Smith", "+1 987 654 3210", "39 years", "Heart Attack",
                " 45 Oak Avenue, Midtown",
                "MetroCare Ambulance (AMB-014)",
                "Driver: Sarah Lee", "Driver: XY-412",
                "ETA: 3 minutes", "Distance: 1.2 km",
                "Today at 3:05 PM", "Today at 3:06 PM", "Today at 3:07 PM - Current"
        ));
        map.put(R.id.request_details_3, new RequestData(
                "#AMB12346", "Completed", "Patient transported",
                "Robert Wilson", "+1 555 222 1111", "52 years", "Accident",
                " 78 Pine Street, Uptown",
                "City Hospital Ambulance (AMB-009)",
                "Driver: Carlos Diaz", "Driver: BC-209",
                "ETA: —", "Distance: —",
                "Today at 1:10 PM", "Today at 1:12 PM", "Today at 1:25 PM"
        ));
        map.put(R.id.request_details_4, new RequestData(
                "#AMB12347", "Active Emergency", "Ambulance assigned",
                "Emily Davis", "+1 555 999 8888", "29 years", "Stroke",
                " 9 Lake View, Riverside",
                "Central EMS (AMB-022)",
                "Driver: Priya Patel", "Driver: FG-334",
                "ETA: 7 minutes", "Distance: 4.1 km",
                "Today at 4:20 PM", "Today at 4:22 PM", "Today at 4:24 PM - Current"
        ));
        map.put(R.id.request_details_5, new RequestData(
                "#AMB12348", "Active Emergency", "Paramedics on route",
                "Michael Brown", "+1 444 333 2222", "61 years", "Breathing Issue",
                " 12 Harbor Road, Bayside",
                "Harbor EMS (AMB-030)",
                "Driver: Lina Chen", "Driver: JK-557",
                "ETA: 6 minutes", "Distance: 3.0 km",
                "Today at 5:15 PM", "Today at 5:17 PM", "Today at 5:18 PM - Current"
        ));
        return map;
    }

    private void setRequestClick(View view, RequestData data) {
        if (view == null || data == null) return;
        view.setOnClickListener(v -> openDetails(data));
    }

    private void openDetails(RequestData data) {
        Intent intent = new Intent(admin_all_request.this, admin_request_details.class);
        intent.putExtra(admin_request_details.EXTRA_REQUEST_ID, data.requestId);
        intent.putExtra(admin_request_details.EXTRA_STATUS, data.status);
        intent.putExtra(admin_request_details.EXTRA_STATUS_DETAIL, data.statusDetail);
        intent.putExtra(admin_request_details.EXTRA_NAME, data.name);
        intent.putExtra(admin_request_details.EXTRA_CONTACT, data.contact);
        intent.putExtra(admin_request_details.EXTRA_AGE, data.age);
        intent.putExtra(admin_request_details.EXTRA_EMERGENCY_TYPE, data.emergencyType);
        intent.putExtra(admin_request_details.EXTRA_LOCATION, data.location);
        intent.putExtra(admin_request_details.EXTRA_AMBULANCE_INFO, data.ambulanceInfo);
        intent.putExtra(admin_request_details.EXTRA_DRIVER, data.driver);
        intent.putExtra(admin_request_details.EXTRA_VEHICLE, data.vehicle);
        intent.putExtra(admin_request_details.EXTRA_ETA, data.eta);
        intent.putExtra(admin_request_details.EXTRA_DISTANCE, data.distance);
        intent.putExtra(admin_request_details.EXTRA_TIME_CREATED, data.timeCreated);
        intent.putExtra(admin_request_details.EXTRA_TIME_ASSIGNED, data.timeAssigned);
        intent.putExtra(admin_request_details.EXTRA_TIME_ENROUTE, data.timeEnroute);
        startActivity(intent);
    }
}