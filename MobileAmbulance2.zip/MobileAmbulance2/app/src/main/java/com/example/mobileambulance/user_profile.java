package com.example.mobileambulance;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class user_profile extends AppCompatActivity {

    private ImageView img_ambulance;
    private ImageView img_home;
    private ImageView img_clipboard;
    private ImageView edit_profile, img_logout;
    private TextView txtName, txtEmail, txtLogoName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_profile);

        // Get user data and update UI
        txtName = findViewById(R.id.name);        // Using the 'name' TextView for the full name
        txtEmail = findViewById(R.id.email);      // Using the 'email' TextView for the email
        txtLogoName = findViewById(R.id.logoname); // Using the 'logoname' TextView for the user's initial
        
        SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
        String username = prefs.getString("username", "");
        String email = prefs.getString("email", "");
        
        if (txtName != null) {
            txtName.setText(username);
        }
        if (txtEmail != null) {
            txtEmail.setText(email);
        }
        if (txtLogoName != null && !username.isEmpty()) {
            // Get first character of username and convert to uppercase
            String initial = username.substring(0, 1).toUpperCase();
            txtLogoName.setText(initial);
        }

        img_ambulance = findViewById(R.id.img_ambulance);
        img_ambulance.setOnClickListener(v -> {
            Intent intent = new Intent(user_profile.this, find_nearby_ambulances.class);
            startActivity(intent);
        });

        img_home = findViewById(R.id.img_home);
        img_home.setOnClickListener(v -> {
            Intent intent = new Intent(user_profile.this, home_dashboard.class);
            startActivity(intent);
        });

        img_clipboard = findViewById(R.id.img_clipboard);
        img_clipboard.setOnClickListener(v -> {
            Intent intent = new Intent(user_profile.this, request_history.class);
            startActivity(intent);
        });

        edit_profile = findViewById(R.id.edit_profile);
        edit_profile.setOnClickListener(v -> {
            Intent intent = new Intent(user_profile.this, edit_profile.class);
            startActivity(intent);
        });

        // Logout button click handler
        img_logout = findViewById(R.id.logout);
        img_logout.setOnClickListener(v -> {
            // Only clear the login state, not all user data
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("isLoggedIn", false);
            editor.apply();
            
            // Navigate to login activity and clear back stack
            Intent intent = new Intent(user_profile.this, login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.user_profile), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}