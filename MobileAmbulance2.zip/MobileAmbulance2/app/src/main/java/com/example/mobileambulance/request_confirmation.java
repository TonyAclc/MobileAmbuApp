package com.example.mobileambulance;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class request_confirmation extends AppCompatActivity {


    private TextView back_to_home;
    private ImageView trackAmbulanceButton;
    private TextView textPatientName;
    private TextView textEmergencyAccident;
    private TextView textAmbulanceId;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_request_confirmation);

        // Initialize TextViews for patient data
        textPatientName = findViewById(R.id.text_patient_name);
        textEmergencyAccident = findViewById(R.id.text_emergency_accident);
        textAmbulanceId = findViewById(R.id.text_ambulance_id);

        // Get data from Intent extras
        Intent intent = getIntent();
        String patientName = intent.getStringExtra("patient_name");
        String emergencyType = intent.getStringExtra("emergency_type");
        String ambulanceId = intent.getStringExtra("ambulance_id");

        // Update TextViews with received data
        if (patientName != null && !patientName.isEmpty()) {
            textPatientName.setText(patientName);
        }
        if (emergencyType != null && !emergencyType.isEmpty()) {
            textEmergencyAccident.setText(emergencyType);
        }
        if (ambulanceId != null && !ambulanceId.isEmpty()) {
            textAmbulanceId.setText(ambulanceId);
        }


        back_to_home = findViewById(R.id.back_to_home);
        if (back_to_home != null) {
            back_to_home.setOnClickListener(v -> {
                Intent homeIntent = new Intent(request_confirmation.this, home_dashboard.class);
                startActivity(homeIntent);
            });
        }

        trackAmbulanceButton = findViewById(R.id.track_ambulance);
        if (trackAmbulanceButton != null) {
            trackAmbulanceButton.setOnClickListener(v -> {
                Intent trackIntent = new Intent(request_confirmation.this, live_ambulance_tracking.class);
                startActivity(trackIntent);
            });
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.request_confirmation), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}