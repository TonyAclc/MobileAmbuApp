    package com.example.mobileambulance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class admin_dashboard_overview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_admin_dashboard_overview);

        View ambulance = findViewById(R.id.Ambulance);
        if (ambulance != null) {
            ambulance.setOnClickListener(v -> {
                Intent intent = new Intent(admin_dashboard_overview.this, admin_ambulance_management.class);
                startActivity(intent);
            });
        }

        View manageAmbu = findViewById(R.id.manage_ambu);
        if (manageAmbu != null) {
            manageAmbu.setOnClickListener(v -> {
                Intent intent = new Intent(admin_dashboard_overview.this, admin_driver_management.class);
                startActivity(intent);
            });
        }

        View manageDrivers = findViewById(R.id.manage_drivers);
        if (manageDrivers != null) {
            manageDrivers.setOnClickListener(v -> {
                Intent intent = new Intent(admin_dashboard_overview.this, admin_driver_management.class);
                startActivity(intent);
            });
        }

        View userManagement = findViewById(R.id.user_management);
        if (userManagement != null) {
            userManagement.setOnClickListener(v -> {
                Intent intent = new Intent(admin_dashboard_overview.this, admin_user_management.class);
                startActivity(intent);
            });
        }

        View requests = findViewById(R.id.Requests);
        if (requests != null) {
            requests.setOnClickListener(v -> {
                Intent intent = new Intent(admin_dashboard_overview.this, admin_all_request.class);
                startActivity(intent);
            });
        }

        View viewAll = findViewById(R.id.view_all);
        if (viewAll != null) {
            viewAll.setOnClickListener(v -> {
                Intent intent = new Intent(admin_dashboard_overview.this, admin_all_request.class);
                startActivity(intent);
            });
        }

        View analytics = findViewById(R.id.Analytics);
        if (analytics != null) {
            analytics.setOnClickListener(v -> {
                Intent intent = new Intent(admin_dashboard_overview.this, admin_analytics_and_reports.class);
                startActivity(intent);
            });
        }

        View analyticsBtn = findViewById(R.id.analyticsbtn);
        if (analyticsBtn != null) {
            analyticsBtn.setOnClickListener(v -> {
                Intent intent = new Intent(admin_dashboard_overview.this, admin_analytics_and_reports.class);
                startActivity(intent);
            });
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.admin_dashboard_overview), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}