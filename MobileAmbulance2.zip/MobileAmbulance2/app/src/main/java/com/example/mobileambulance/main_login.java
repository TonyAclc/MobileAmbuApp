package com.example.mobileambulance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class main_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.container_m_login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.User_Login).setOnClickListener(v -> {
            Intent intent = new Intent(main_login.this, login.class);
            startActivity(intent);
        });

        View.OnClickListener adminLoginClickListener = v -> {
            Intent intent = new Intent(main_login.this, admin_dashboard_overview.class);
            startActivity(intent);
        };

        int[] adminLoginTargets = new int[] {
                R.id.Admin_Login,
                R.id.text_admin_login,
                R.id.text_hospital_management_access
        };

        for (int targetId : adminLoginTargets) {
            View targetView = findViewById(targetId);
            if (targetView != null) {
                targetView.setOnClickListener(adminLoginClickListener);
            }
        }

        View superAdminButton = findViewById(R.id.spr_adminbtn);
        if (superAdminButton != null) {
            superAdminButton.setOnClickListener(v -> {
                Intent intent = new Intent(main_login.this, super_admin_dashboard.class);
                startActivity(intent);
            });
        }

        View backButton = findViewById(R.id.backbtn);
        if (backButton != null) {
            backButton.setOnClickListener(v -> {
                Intent intent = new Intent(main_login.this, MainActivity.class);
                startActivity(intent);
            });
        }
    }
}