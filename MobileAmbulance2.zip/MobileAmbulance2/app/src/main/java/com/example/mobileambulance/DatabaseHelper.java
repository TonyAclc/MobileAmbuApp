package com.example.mobileambulance;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.preference.PreferenceManager;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    
    private static final String DATABASE_NAME = "AmbulanceRequests.db";
    private static final int DATABASE_VERSION = 2;
    private static DatabaseHelper instance;
    private Context context;
    
    // Table name
    private static final String TABLE_REQUESTS = "requests";
    
    // Column names
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_AMBULANCE_ID = "ambulance_id";
    private static final String COLUMN_PATIENT_NAME = "patient_name";
    private static final String COLUMN_CONTACT_NUMBER = "contact_number";
    private static final String COLUMN_PATIENT_AGE = "patient_age";
    private static final String COLUMN_EMERGENCY_TYPE = "emergency_type";
    private static final String COLUMN_ADDRESS = "address";
    private static final String COLUMN_LOCATION = "location";
    private static final String COLUMN_TIMESTAMP = "timestamp";
    private static final String COLUMN_STATUS = "status";
    
    // Create table query
    private static final String CREATE_TABLE_REQUESTS = 
        "CREATE TABLE " + TABLE_REQUESTS + " (" +
        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
        COLUMN_USER_ID + " TEXT, " +
        COLUMN_AMBULANCE_ID + " TEXT, " +
        COLUMN_PATIENT_NAME + " TEXT, " +
        COLUMN_CONTACT_NUMBER + " TEXT, " +
        COLUMN_PATIENT_AGE + " TEXT, " +
        COLUMN_EMERGENCY_TYPE + " TEXT, " +
        COLUMN_ADDRESS + " TEXT, " +
        COLUMN_LOCATION + " TEXT, " +
        COLUMN_TIMESTAMP + " TEXT, " +
        COLUMN_STATUS + " TEXT" +
        ")";
    
    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }
    
    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_REQUESTS);
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REQUESTS);
        onCreate(db);
    }
    
    // Add new request
    public long addRequest(Request request) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        // Get current user ID
        String userId = getCurrentUserId();
        
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_AMBULANCE_ID, request.getAmbulanceId());
        values.put(COLUMN_PATIENT_NAME, request.getPatientName());
        values.put(COLUMN_CONTACT_NUMBER, request.getContactNumber());
        values.put(COLUMN_PATIENT_AGE, request.getPatientAge());
        values.put(COLUMN_EMERGENCY_TYPE, request.getEmergencyType());
        values.put(COLUMN_ADDRESS, request.getAddress());
        values.put(COLUMN_LOCATION, request.getLocation());
        values.put(COLUMN_TIMESTAMP, request.getTimestamp());
        values.put(COLUMN_STATUS, request.getStatus());
        
        long id = db.insert(TABLE_REQUESTS, null, values);
        db.close();
        return id;
    }
    
    // Get current user ID from SharedPreferences
    private String getCurrentUserId() {
        SharedPreferences prefs = context.getSharedPreferences("UserData", Context.MODE_PRIVATE);
        return prefs.getString("username", "anonymous");
    }
    
    // Get all requests for current user (most recent first)
    public List<Request> getAllRequests() {
        List<Request> requests = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        
        // Get current user ID
        String userId = getCurrentUserId();
        
        Cursor cursor = db.query(TABLE_REQUESTS, null, COLUMN_USER_ID + " = ?", 
                                new String[]{userId}, null, null, 
                                COLUMN_TIMESTAMP + " DESC");
        
        if (cursor.moveToFirst()) {
            do {
                Request request = new Request();
                request.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                request.setAmbulanceId(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AMBULANCE_ID)));
                request.setPatientName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PATIENT_NAME)));
                request.setContactNumber(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CONTACT_NUMBER)));
                request.setPatientAge(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PATIENT_AGE)));
                request.setEmergencyType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMERGENCY_TYPE)));
                request.setAddress(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ADDRESS)));
                request.setLocation(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LOCATION)));
                request.setTimestamp(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP)));
                request.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
                requests.add(request);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        return requests;
    }
    
    // Get recent requests (limit to 10)
    public List<Request> getRecentRequests(int limit) {
        List<Request> requests = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        
        Cursor cursor = db.query(TABLE_REQUESTS, null, null, null, null, null, 
                                COLUMN_TIMESTAMP + " DESC", String.valueOf(limit));
        
        if (cursor.moveToFirst()) {
            do {
                Request request = new Request();
                request.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                request.setAmbulanceId(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AMBULANCE_ID)));
                request.setPatientName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PATIENT_NAME)));
                request.setContactNumber(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CONTACT_NUMBER)));
                request.setPatientAge(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PATIENT_AGE)));
                request.setEmergencyType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMERGENCY_TYPE)));
                request.setAddress(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ADDRESS)));
                request.setLocation(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LOCATION)));
                request.setTimestamp(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP)));
                request.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
                requests.add(request);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        return requests;
    }
    
    // Delete all requests (for testing)
    public void deleteAllRequests() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_REQUESTS, null, null);
        db.close();
    }
    
    // Delete all requests for current user
    public void deleteUserRequests() {
        SQLiteDatabase db = this.getWritableDatabase();
        String userId = getCurrentUserId();
        db.delete(TABLE_REQUESTS, COLUMN_USER_ID + " = ?", new String[]{userId});
        db.close();
    }
    
    // Force database upgrade to add user_id column
    public void forceDatabaseUpgrade() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REQUESTS);
        onCreate(db);
        db.close();
    }
}
