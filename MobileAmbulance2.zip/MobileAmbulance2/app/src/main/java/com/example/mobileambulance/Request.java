package com.example.mobileambulance;

public class Request {
    private int id;
    private String ambulanceId;
    private String patientName;
    private String contactNumber;
    private String patientAge;
    private String emergencyType;
    private String address;
    private String location;
    private String timestamp;
    private String status;
    
    public Request() {
        this.status = "Completed"; // Default status
    }
    
    public Request(String ambulanceId, String patientName, String emergencyType, String timestamp) {
        this.ambulanceId = ambulanceId;
        this.patientName = patientName;
        this.emergencyType = emergencyType;
        this.timestamp = timestamp;
        this.status = "Completed";
    }
    
    // Getters and Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getAmbulanceId() {
        return ambulanceId;
    }
    
    public void setAmbulanceId(String ambulanceId) {
        this.ambulanceId = ambulanceId;
    }
    
    public String getPatientName() {
        return patientName;
    }
    
    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
    
    public String getContactNumber() {
        return contactNumber;
    }
    
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }
    
    public String getPatientAge() {
        return patientAge;
    }
    
    public void setPatientAge(String patientAge) {
        this.patientAge = patientAge;
    }
    
    public String getEmergencyType() {
        return emergencyType;
    }
    
    public void setEmergencyType(String emergencyType) {
        this.emergencyType = emergencyType;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public String getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    // Helper method to get display text
    public String getDisplayText() {
        return ambulanceId + " - " + patientName;
    }
    
    @Override
    public String toString() {
        return "Request{" +
                "id=" + id +
                ", ambulanceId='" + ambulanceId + '\'' +
                ", patientName='" + patientName + '\'' +
                ", emergencyType='" + emergencyType + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
