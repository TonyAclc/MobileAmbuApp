package com.example.mobileambulance;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class superadmin_analytics_reports extends AppCompatActivity {

    private ImageView Dashboard;
    private ImageView Hospitals;
    private ImageView Admins;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_superadmin_analytics_reports);

        Dashboard = findViewById(R.id.Dashboard);
        Dashboard.setOnClickListener(v -> {
            startActivity(new Intent(this, super_admin_dashboard.class));
        });

        Hospitals = findViewById(R.id.Hospitals);
        Hospitals.setOnClickListener(v -> {
            startActivity(new Intent(this, superadmin_hospital_management.class));
        });

        Admins = findViewById(R.id.Admins);
        Admins.setOnClickListener(v -> {
            startActivity(new Intent(this, superadmin_user_management.class));
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.superadmin_analytics_reports), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}