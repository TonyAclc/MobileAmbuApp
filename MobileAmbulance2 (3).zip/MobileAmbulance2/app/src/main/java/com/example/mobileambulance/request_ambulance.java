package com.example.mobileambulance;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextUtils;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import java.util.Random;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class request_ambulance extends AppCompatActivity {

    private ImageView homebtn;
    private ImageView clipboardbtn;
    private ImageView userbtn;
    private View submitButton;
    
    // Emergency type selection
    private View accidentOption, heartAttackOption, strokeOption, otherEmergencyOption;
    private ImageView ellipse1, ellipse2, ellipse3, ellipse4;
    private String selectedEmergencyType = "";
    
    // Input fields
    private EditText patientNameInput;
    private EditText contactNumberInput;
    private EditText patientAgeInput;
    private EditText addressInput;
    
    // Location selection
    private View currentLocationBtn, chooseOnMapBtn;
    private String selectedLocation = "";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_request_ambulance);

        homebtn = findViewById(R.id.homebtn);
        homebtn.setOnClickListener(v -> {
            Intent intent = new Intent(request_ambulance.this, home_dashboard.class);
            startActivity(intent);
        });

        clipboardbtn = findViewById(R.id.clipboardbtn);
        clipboardbtn.setOnClickListener(v -> {
            Intent intent = new Intent(request_ambulance.this, request_history.class);
            startActivity(intent);
        });

        userbtn = findViewById(R.id.userbtn);
        userbtn.setOnClickListener(v -> {
            Intent intent = new Intent(request_ambulance.this, user_profile.class);
            startActivity(intent);
        });

        submitButton = findViewById(R.id.submitbtn);
        if (submitButton != null) {
            submitButton.setOnClickListener(v -> {
                if (validateForm()) {
                    // Generate random ambulance ID
                    String ambulanceId = generateAmbulanceId();
                    
                    Intent confirmIntent = new Intent(request_ambulance.this, request_confirmation.class);
                    
                    // Pass form data to confirmation activity
                    confirmIntent.putExtra("patient_name", getPatientName());
                    confirmIntent.putExtra("contact_number", getContactNumber());
                    confirmIntent.putExtra("patient_age", getPatientAge());
                    confirmIntent.putExtra("emergency_type", getSelectedEmergencyType());
                    confirmIntent.putExtra("address", getAddress());
                    confirmIntent.putExtra("location", getSelectedLocation());
                    confirmIntent.putExtra("ambulance_id", ambulanceId);
                    
                    // Show success notification
                    Toast.makeText(request_ambulance.this, "Request submitted successfully!", Toast.LENGTH_SHORT).show();
                    
                    // Add to request history
                    DatabaseHelper dbHelper = DatabaseHelper.getInstance(request_ambulance.this);
                    Request request = new Request();
                    request.setAmbulanceId(ambulanceId);
                    request.setPatientName(getPatientName());
                    request.setContactNumber(getContactNumber());
                    request.setPatientAge(getPatientAge());
                    request.setEmergencyType(getSelectedEmergencyType());
                    request.setAddress(getAddress());
                    request.setLocation(getSelectedLocation());
                    request.setStatus("Completed");
                    
                    // Set timestamp
                    SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy - hh:mm a", Locale.getDefault());
                    request.setTimestamp(sdf.format(new Date()));
                    
                    // Debug logging
                    android.util.Log.d("RequestAmbulance", "Saving request: " + 
                        request.getEmergencyType() + " - " + request.getDisplayText() + " - " + request.getTimestamp());
                    
                    long result = dbHelper.addRequest(request);
                    android.util.Log.d("RequestAmbulance", "Request saved with ID: " + result);
                    
                    startActivity(confirmIntent);
                }
            });
        }
        
        initializeEmergencySelection();
        initializeInputFields();
        initializeLocationSelection();
        
        View root = findViewById(R.id.container_request_ambulance);
        if (root != null) {
            ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
    }
    
    private void initializeEmergencySelection() {
        // Find emergency type options
        accidentOption = findViewById(R.id.img_rectangle18);
        heartAttackOption = findViewById(R.id.img_rectangle19);
        strokeOption = findViewById(R.id.img_rectangle20);
        otherEmergencyOption = findViewById(R.id.img_rectangle21);
        
        // Find ellipse indicators
        ellipse1 = findViewById(R.id.img_ellipse4);  // Accident
        ellipse2 = findViewById(R.id.img_ellipse);   // Heart Attack
        ellipse3 = findViewById(R.id.img_ellipse2);  // Stroke
        ellipse4 = findViewById(R.id.img_ellipse3);  // Other Emergency
        
        // Set click listeners for emergency options
        View.OnClickListener emergencyClickListener = v -> {
            selectedEmergencyType = getEmergencyType(v.getId());
            updateEllipseSelection(v);
            Toast.makeText(this, "Selected: " + selectedEmergencyType, Toast.LENGTH_SHORT).show();
        };
        
        accidentOption.setOnClickListener(emergencyClickListener);
        heartAttackOption.setOnClickListener(emergencyClickListener);
        strokeOption.setOnClickListener(emergencyClickListener);
        otherEmergencyOption.setOnClickListener(emergencyClickListener);
    }
    
    private String getEmergencyType(int viewId) {
        if (viewId == R.id.img_rectangle18) return "Accident";
        else if (viewId == R.id.img_rectangle19) return "Heart Attack";
        else if (viewId == R.id.img_rectangle20) return "Stroke";
        else if (viewId == R.id.img_rectangle21) return "Other Emergency";
        else return "";
    }
    
    private void updateEllipseSelection(View selectedOption) {
        // Reset all ellipses to original state
        resetEllipse(ellipse1);
        resetEllipse(ellipse2);
        resetEllipse(ellipse3);
        resetEllipse(ellipse4);
        
        // Fill the selected ellipse with blue
        if (selectedOption.getId() == R.id.img_rectangle18 && ellipse1 != null) {
            fillEllipseWithBlue(ellipse1);
        } else if (selectedOption.getId() == R.id.img_rectangle19 && ellipse2 != null) {
            fillEllipseWithBlue(ellipse2);
        } else if (selectedOption.getId() == R.id.img_rectangle20 && ellipse3 != null) {
            fillEllipseWithBlue(ellipse3);
        } else if (selectedOption.getId() == R.id.img_rectangle21 && ellipse4 != null) {
            fillEllipseWithBlue(ellipse4);
        }
    }
    
    private void resetEllipse(ImageView ellipse) {
        if (ellipse == null) return;
        
        // Reset to original drawable (empty circle)
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setStroke(2, Color.GRAY); // Gray outline
        circle.setColor(Color.TRANSPARENT); // Transparent inside
        circle.setSize(17, 17);
        
        ellipse.setImageDrawable(circle);
    }
    
    private void fillEllipseWithBlue(ImageView ellipse) {
        if (ellipse == null) return;
        
        // Create blue filled circle
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.BLUE); // Blue fill
        circle.setStroke(2, Color.BLUE); // Blue outline
        circle.setSize(17, 17);
        
        ellipse.setImageDrawable(circle);
    }
    
    private void initializeInputFields() {
        // Find existing TextViews and replace them with EditTexts
        TextView patientNameText = findViewById(R.id.text_enter_patient_name);
        TextView contactNumberText = findViewById(R.id.text_phone_number);
        TextView patientAgeText = findViewById(R.id.text_patient_age1);
        TextView addressText = findViewById(R.id.text_enter_address);
        
        // Replace Patient Name TextView with EditText
        if (patientNameText != null) {
            android.view.ViewGroup parent = (android.view.ViewGroup) patientNameText.getParent();
            int index = parent.indexOfChild(patientNameText);
            
            patientNameInput = new EditText(this);
            patientNameInput.setHint("Enter patient name");
            patientNameInput.setId(R.id.text_enter_patient_name);
            patientNameInput.setLayoutParams(patientNameText.getLayoutParams());
            patientNameInput.setPadding(patientNameText.getPaddingLeft(), patientNameText.getPaddingTop(), 
                                       patientNameText.getPaddingRight(), patientNameText.getPaddingBottom());
            patientNameInput.setTextColor(patientNameText.getTextColors());
            patientNameInput.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, patientNameText.getTextSize());
            patientNameInput.setBackgroundColor(Color.TRANSPARENT);
            
            parent.removeView(patientNameText);
            parent.addView(patientNameInput, index);
        }
        
        // Replace Contact Number TextView with EditText
        if (contactNumberText != null) {
            android.view.ViewGroup parent = (android.view.ViewGroup) contactNumberText.getParent();
            int index = parent.indexOfChild(contactNumberText);
            
            contactNumberInput = new EditText(this);
            contactNumberInput.setHint("+63 917 123 4567");
            contactNumberInput.setInputType(InputType.TYPE_CLASS_PHONE);
            contactNumberInput.setId(R.id.text_phone_number);
            contactNumberInput.setLayoutParams(contactNumberText.getLayoutParams());
            contactNumberInput.setPadding(contactNumberText.getPaddingLeft(), contactNumberText.getPaddingTop(), 
                                        contactNumberText.getPaddingRight(), contactNumberText.getPaddingBottom());
            contactNumberInput.setTextColor(contactNumberText.getTextColors());
            contactNumberInput.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, contactNumberText.getTextSize());
            contactNumberInput.setBackgroundColor(Color.TRANSPARENT);
            
            parent.removeView(contactNumberText);
            parent.addView(contactNumberInput, index);
        }
        
        // Replace Patient Age TextView with EditText
        if (patientAgeText != null) {
            android.view.ViewGroup parent = (android.view.ViewGroup) patientAgeText.getParent();
            int index = parent.indexOfChild(patientAgeText);
            
            patientAgeInput = new EditText(this);
            patientAgeInput.setHint("Enter age");
            patientAgeInput.setInputType(InputType.TYPE_CLASS_NUMBER);
            patientAgeInput.setKeyListener(DigitsKeyListener.getInstance("0123456789"));
            patientAgeInput.setId(R.id.text_patient_age1);
            patientAgeInput.setLayoutParams(patientAgeText.getLayoutParams());
            patientAgeInput.setPadding(patientAgeText.getPaddingLeft(), patientAgeText.getPaddingTop(), 
                                     patientAgeText.getPaddingRight(), patientAgeText.getPaddingBottom());
            patientAgeInput.setTextColor(patientAgeText.getTextColors());
            patientAgeInput.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, patientAgeText.getTextSize());
            patientAgeInput.setBackgroundColor(Color.TRANSPARENT);
            
            parent.removeView(patientAgeText);
            parent.addView(patientAgeInput, index);
        }
        
        // Replace Address TextView with EditText
        if (addressText != null) {
            android.view.ViewGroup parent = (android.view.ViewGroup) addressText.getParent();
            int index = parent.indexOfChild(addressText);
            
            addressInput = new EditText(this);
            addressInput.setHint("Enter specific address (optional)");
            addressInput.setId(R.id.text_enter_address);
            addressInput.setLayoutParams(addressText.getLayoutParams());
            addressInput.setPadding(addressText.getPaddingLeft(), addressText.getPaddingTop(), 
                                  addressText.getPaddingRight(), addressText.getPaddingBottom());
            addressInput.setTextColor(addressText.getTextColors());
            addressInput.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, addressText.getTextSize());
            addressInput.setBackgroundColor(Color.TRANSPARENT);
            
            parent.removeView(addressText);
            parent.addView(addressInput, index);
        }
    }
    
    private void initializeLocationSelection() {
        currentLocationBtn = findViewById(R.id.img_rectangle16);
        chooseOnMapBtn = findViewById(R.id.img_rectangle17);
        
        currentLocationBtn.setOnClickListener(v -> {
            selectedLocation = "Current Location";
            highlightLocationButton(currentLocationBtn);
            unhighlightLocationButton(chooseOnMapBtn);
            getCurrentLocation();
            Toast.makeText(this, "Current location selected", Toast.LENGTH_SHORT).show();
        });
        
        chooseOnMapBtn.setOnClickListener(v -> {
            selectedLocation = "Choose on Map";
            highlightLocationButton(chooseOnMapBtn);
            unhighlightLocationButton(currentLocationBtn);
            openMapSelection();
            Toast.makeText(this, "Map selection", Toast.LENGTH_SHORT).show();
        });
    }
    
    private void getCurrentLocation() {
        // TODO: Implement GPS location retrieval
        if (addressInput != null) {
            addressInput.setText("Current GPS Location detected");
        }
    }
    
    private void openMapSelection() {
        // TODO: Implement map selection activity
        Intent intent = new Intent(this, find_nearby_hospitals.class);
        startActivity(intent);
    }
    
    private void highlightLocationButton(View button) {
        GradientDrawable background = new GradientDrawable();
        background.setShape(GradientDrawable.RECTANGLE);
        background.setColor(Color.parseColor("#E3F2FD"));
        background.setStroke(2, Color.BLUE);
        button.setBackground(background);
    }
    
    private void unhighlightLocationButton(View button) {
        button.setBackgroundColor(Color.TRANSPARENT);
    }
    
    // Getter methods for form data
    public String getPatientName() {
        return patientNameInput != null ? patientNameInput.getText().toString().trim() : "";
    }
    
    public String getContactNumber() {
        return contactNumberInput != null ? contactNumberInput.getText().toString().trim() : "";
    }
    
    public String getPatientAge() {
        return patientAgeInput != null ? patientAgeInput.getText().toString().trim() : "";
    }
    
    public String getAddress() {
        return addressInput != null ? addressInput.getText().toString().trim() : "";
    }
    
    public String getSelectedEmergencyType() {
        return selectedEmergencyType;
    }
    
    public String getSelectedLocation() {
        return selectedLocation;
    }
    
    public boolean validateForm() {
        boolean isValid = true;
        
        if (TextUtils.isEmpty(getPatientName())) {
            if (patientNameInput != null) {
                patientNameInput.setError("Patient name is required");
            }
            isValid = false;
        }
        
        if (TextUtils.isEmpty(getContactNumber())) {
            if (contactNumberInput != null) {
                contactNumberInput.setError("Contact number is required");
            }
            isValid = false;
        }
        
        if (TextUtils.isEmpty(selectedEmergencyType)) {
            Toast.makeText(this, "Please select an emergency type", Toast.LENGTH_SHORT).show();
            isValid = false;
        }
        
        if (TextUtils.isEmpty(selectedLocation)) {
            Toast.makeText(this, "Please select a pickup location", Toast.LENGTH_SHORT).show();
            isValid = false;
        }
        
        return isValid;
    }
    
    // Generate random ambulance ID
    private String generateAmbulanceId() {
        Random random = new Random();
        int number = 10000 + random.nextInt(90000); // Generate 5-digit number
        return "#AMB" + number;
    }
}