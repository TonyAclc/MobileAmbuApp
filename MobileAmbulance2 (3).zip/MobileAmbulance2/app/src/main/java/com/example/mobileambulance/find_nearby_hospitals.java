package com.example.mobileambulance;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class find_nearby_hospitals extends AppCompatActivity {
    
    private LinearLayout homeBtn, ambulanceBtn, historyBtn, profileBtn;
    private ImageView callBtn1, callBtn2, callBtn3, callBtn4;
    private Dialog callDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_find_nearby_hospitals);
        
        // Initialize views
        homeBtn = findViewById(R.id.nav_home);
        ambulanceBtn = findViewById(R.id.nav_ambulance);
        historyBtn = findViewById(R.id.nav_history);
        profileBtn = findViewById(R.id.nav_profile);
        
        // Set click listeners
        homeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(find_nearby_hospitals.this, home_dashboard.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
        
        ambulanceBtn.setOnClickListener(v -> {
            Intent intent = new Intent(find_nearby_hospitals.this, find_nearby_ambulances.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
        
        historyBtn.setOnClickListener(v -> {
            Intent intent = new Intent(find_nearby_hospitals.this, request_history.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
        
        profileBtn.setOnClickListener(v -> {
            Intent intent = new Intent(find_nearby_hospitals.this, user_profile.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
        
        // Initialize call buttons
        initializeCallButtons();
        
        // Get the root view of the activity
        View rootView = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initializeCallButtons() {
        // Initialize call buttons
        callBtn1 = findViewById(R.id.callbtn1);
        callBtn2 = findViewById(R.id.callbtn2);
        callBtn3 = findViewById(R.id.callbtn3);
        callBtn4 = findViewById(R.id.callbtn4);
        
        // Set click listeners for call buttons
        if (callBtn1 != null) {
            callBtn1.setOnClickListener(v -> showCallDialog("City General Hospital", "+1 234 567 890"));
        }
        if (callBtn2 != null) {
            callBtn2.setOnClickListener(v -> showCallDialog("Metro Medical Center", "+1 234 567 891"));
        }
        if (callBtn3 != null) {
            callBtn3.setOnClickListener(v -> showCallDialog("Unity Health Hospital", "+1 234 567 892"));
        }
        if (callBtn4 != null) {
            callBtn4.setOnClickListener(v -> showCallDialog("Sunrise Medical Center", "+1 234 567 893"));
        }
    }

    private void showCallDialog(String hospitalName, String phoneNumber) {
        // Create dialog
        callDialog = new Dialog(this);
        callDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        callDialog.setContentView(R.layout.dialog_call);
        callDialog.setCancelable(true);
        
        // Make dialog background transparent
        if (callDialog.getWindow() != null) {
            callDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        // Initialize views
        TextView tvHospitalName = callDialog.findViewById(R.id.tvHospitalName);
        TextView tvPhoneNumber = callDialog.findViewById(R.id.tvPhoneNumber);
        Button btnCallNow = callDialog.findViewById(R.id.btnCallNow);

        // Set hospital info
        tvHospitalName.setText(hospitalName);
        tvPhoneNumber.setText(phoneNumber);

        // Call Now button click
        btnCallNow.setOnClickListener(v -> {
            // Create phone call intent
            Intent callIntent = new Intent(Intent.ACTION_DIAL);
            callIntent.setData(Uri.parse("tel:" + phoneNumber));
            startActivity(callIntent);
            callDialog.dismiss();
        });

        // Show dialog
        callDialog.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (callDialog != null && callDialog.isShowing()) {
            callDialog.dismiss();
        }
    }
}