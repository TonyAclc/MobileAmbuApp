package com.example.mobileambulance;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class login extends AppCompatActivity {

    private TextView signIn;
    private TextView loginButton;
    private EditText etUsernameEmail, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Check if user is already logged in
        if (isLoggedIn()) {
            startActivity(new Intent(this, home_dashboard.class));
            finish();
            return;
        }
        
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Initialize views
        signIn = findViewById(R.id.signIn);
        loginButton = findViewById(R.id.loginButton);
        etUsernameEmail = findViewById(R.id.usernameEdit);
        etPassword = findViewById(R.id.passwordEdit);

        signIn.setOnClickListener(v -> {
            Intent intent = new Intent(login.this, signin.class);
            startActivity(intent);
        });

        loginButton.setOnClickListener(v -> {
            // Get user input
            String inputUser = etUsernameEmail.getText().toString().trim();
            String inputPass = etPassword.getText().toString().trim();

            // Basic validation
            if (inputUser.isEmpty() || inputPass.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get saved user data
            SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
            String savedUsername = prefs.getString("username", null);
            String savedEmail = prefs.getString("email", null);
            String savedPassword = prefs.getString("password", null);

            // Check if user is registered
            if (savedPassword == null) {
                Toast.makeText(this, "User not registered. Please sign up first.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate login
            if ((inputUser.equals(savedUsername) || inputUser.equals(savedEmail))
                    && inputPass.equals(savedPassword)) {
                // Set login state
                SharedPreferences.Editor editor = prefs.edit();
                editor.putBoolean("isLoggedIn", true);
                editor.apply();
                
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(login.this, home_dashboard.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid username/email or password", Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    
    private boolean isLoggedIn() {
        SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
        return prefs.getBoolean("isLoggedIn", false);
    }
}