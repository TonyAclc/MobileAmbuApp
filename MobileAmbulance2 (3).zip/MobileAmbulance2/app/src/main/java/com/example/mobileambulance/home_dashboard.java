package com.example.mobileambulance;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.SharedPreferences;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class home_dashboard extends AppCompatActivity {

    private ImageView container_ambulance;
    private ImageView emergencyCallBtn;
    private ImageView findAmbulance;
    private ImageView requestBtn;
    private ImageView myRequestBtn;
    private ImageView container_clipboard1;
    private ImageView container_user;
    private ImageView callHospital;
    private TextView displayName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home_dashboard);

        // Get user data and update UI
        displayName = findViewById(R.id.displayname);
        SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
        String username = prefs.getString("username", "User");
        if (displayName != null) {
            displayName.setText(username);
        }

        container_ambulance = findViewById(R.id.container_ambulance);
        if (container_ambulance != null) {
            container_ambulance.setOnClickListener(v -> {
                Intent intent = new Intent(home_dashboard.this, find_nearby_ambulances.class);
                startActivity(intent);
            });
        }

        emergencyCallBtn = findViewById(R.id.e_call);
        if (emergencyCallBtn != null) {
            emergencyCallBtn.setOnClickListener(v -> {
                Intent intent = new Intent(home_dashboard.this, emergency_call.class);
                startActivity(intent);
            });
        }

        findAmbulance = findViewById(R.id.Find_Ambulance);
        if (findAmbulance != null) {
            findAmbulance.setOnClickListener(v -> {
                Intent intent = new Intent(home_dashboard.this, find_nearby_ambulances.class);
                startActivity(intent);
            });
        }

        requestBtn = findViewById(R.id.Requestbtn);
        if (requestBtn != null) {
            requestBtn.setOnClickListener(v -> {
                Intent intent = new Intent(home_dashboard.this, request_ambulance.class);
                startActivity(intent);
            });
        }

        myRequestBtn = findViewById(R.id.My_Requestbtn);
        if (myRequestBtn != null) {
            myRequestBtn.setOnClickListener(v -> {
                Intent intent = new Intent(home_dashboard.this, request_history.class);
                startActivity(intent);
            });
        }

        container_clipboard1 = findViewById(R.id.container_clipboard1);
        if (container_clipboard1 != null) {
            container_clipboard1.setOnClickListener(v -> {
                Intent intent = new Intent(home_dashboard.this, request_history.class);
                startActivity(intent);
            });
        }

        container_user = findViewById(R.id.container_user);
        if (container_user != null) {
            container_user.setOnClickListener(v -> {
                Intent intent = new Intent(home_dashboard.this, user_profile.class);
                startActivity(intent);
            });
        }

        callHospital = findViewById(R.id.call_hospital);
        if (callHospital != null) {
            callHospital.setOnClickListener(v -> {
                Intent intent = new Intent(home_dashboard.this, find_nearby_hospitals.class);
                startActivity(intent);
            });
        }


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.home_dashboard), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}