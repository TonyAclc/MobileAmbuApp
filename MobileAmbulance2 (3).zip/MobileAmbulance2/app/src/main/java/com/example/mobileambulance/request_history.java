package com.example.mobileambulance;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout.LayoutParams;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class request_history extends AppCompatActivity {

    private ImageView img_ambulance;
    private ImageView img_home;
    private ImageView img_user;
    private DatabaseHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_request_history);

            dbHelper = DatabaseHelper.getInstance(this);
            if (dbHelper == null) {
                android.util.Log.e("RequestHistory", "Failed to initialize DatabaseHelper");
                finish();
                return;
            }
            
            android.util.Log.d("RequestHistory", "Views initialized successfully");
            
            // Load history after views are initialized
            loadRequestHistory();

        img_ambulance = findViewById(R.id.img_ambulance);
        if (img_ambulance != null) {
            img_ambulance.setOnClickListener(v -> {
                Intent intent = new Intent(request_history.this, find_nearby_ambulances.class);
                startActivity(intent);
            });
        }

        img_home = findViewById(R.id.img_home);
        if (img_home != null) {
            img_home.setOnClickListener(v -> {
                Intent intent = new Intent(request_history.this, home_dashboard.class);
                startActivity(intent);
            });
        }

        img_user = findViewById(R.id.img_user);
        if (img_user != null) {
            img_user.setOnClickListener(v -> {
                Intent intent = new Intent(request_history.this, user_profile.class);
                startActivity(intent);
            });
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.request_history), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error in onCreate", e);
            finish();
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        try {
            // Clear and refresh history when user returns to this screen
            android.util.Log.d("RequestHistory", "onResume: Refreshing request history");
            loadRequestHistory();
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error in onResume", e);
        }
    }

    // Load and display request history using only original TextViews
    private void loadRequestHistory() {
        try {
            // Get current user ID for debugging
            SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
            String currentUserId = prefs.getString("username", "anonymous");
            android.util.Log.d("RequestHistory", "Current user ID: " + currentUserId);
            
            // Get fresh data from database
            List<Request> requests = dbHelper.getAllRequests();
            
            android.util.Log.d("RequestHistory", "Loading " + requests.size() + " requests from database");
            
            // Clear all original TextViews first
            clearOriginalTextViews();
            
            if (requests.isEmpty()) {
                android.util.Log.d("RequestHistory", "No requests found for user: " + currentUserId);
                return;
            }
            
            // Log request details for debugging
            for (int i = 0; i < requests.size(); i++) {
                Request req = requests.get(i);
                android.util.Log.d("RequestHistory", "Request " + i + ": " + 
                    req.getEmergencyType() + " - " + req.getDisplayText() + " - " + req.getTimestamp());
            }
            
            // Update original TextViews with real data (up to 4 requests)
            updateOriginalTextViews(requests);
            
            // Log for debugging
            android.util.Log.d("RequestHistory", "Successfully loaded " + requests.size() + " requests");
            
        } catch (Exception e) {
            // Log error but don't crash app
            android.util.Log.e("RequestHistory", "Error loading history", e);
        }
    }
    
    // Update original hardcoded TextViews with real data
    private void updateOriginalTextViews(List<Request> requests) {
        try {
            // First request
            if (requests.size() > 0) {
                Request request1 = requests.get(0);
                TextView emergency1 = findViewById(R.id.txt_heart_attack);
                TextView ambulance1 = findViewById(R.id.txt_city_hospital_ambulance);
                TextView time1 = findViewById(R.id.txt_oct_30_pm_1);
                TextView status1 = findViewById(R.id.txt_completed);
                
                // Show first entry elements and backgrounds
                showFirstEntryElements(request1);
                
                if (emergency1 != null) {
                    emergency1.setText(request1.getEmergencyType() != null ? request1.getEmergencyType() : "Heart Attack Emergency");
                    emergency1.setVisibility(View.VISIBLE);
                }
                if (ambulance1 != null) {
                    ambulance1.setText(request1.getDisplayText() != null ? request1.getDisplayText() : "City Hospital Ambulance");
                    ambulance1.setVisibility(View.VISIBLE);
                }
                if (time1 != null) {
                    time1.setText(request1.getTimestamp() != null ? request1.getTimestamp() : "Oct 15, 2025 - 2:30 PM");
                    time1.setVisibility(View.VISIBLE);
                }
                if (status1 != null) {
                    status1.setText(request1.getStatus() != null ? request1.getStatus() : "Completed");
                    status1.setVisibility(View.VISIBLE);
                }
            }
            
            // Second request
            if (requests.size() > 1) {
                Request request2 = requests.get(1);
                TextView emergency2 = findViewById(R.id.txt_road_accident);
                TextView ambulance2 = findViewById(R.id.txt_city_hospital_ambulance1);
                TextView time2 = findViewById(R.id.txt_oct_30_pm_2);
                TextView status2 = findViewById(R.id.txt_completed1);
                
                // Show second entry elements and backgrounds
                showSecondEntryElements(request2);
                
                if (emergency2 != null) {
                    emergency2.setText(request2.getEmergencyType() != null ? request2.getEmergencyType() : "Road Accident");
                    emergency2.setVisibility(View.VISIBLE);
                }
                if (ambulance2 != null) {
                    ambulance2.setText(request2.getDisplayText() != null ? request2.getDisplayText() : "City Hospital Ambulance");
                    ambulance2.setVisibility(View.VISIBLE);
                }
                if (time2 != null) {
                    time2.setText(request2.getTimestamp() != null ? request2.getTimestamp() : "Oct 15, 2025 - 2:30 PM");
                    time2.setVisibility(View.VISIBLE);
                }
                if (status2 != null) {
                    status2.setText(request2.getStatus() != null ? request2.getStatus() : "Completed");
                    status2.setVisibility(View.VISIBLE);
                }
            }
            
            // Third request
            if (requests.size() > 2) {
                Request request3 = requests.get(2);
                TextView emergency3 = findViewById(R.id.txt_breathing_problem);
                TextView ambulance3 = findViewById(R.id.txt_emergency_response_unit);
                TextView time3 = findViewById(R.id.txt_oct_30_pm_3);
                TextView status3 = findViewById(R.id.txt_cancelled);
                
                // Show third entry elements and backgrounds
                showThirdEntryElements(request3);
                
                if (emergency3 != null) {
                    emergency3.setText(request3.getEmergencyType() != null ? request3.getEmergencyType() : "Breathing Problem");
                    emergency3.setVisibility(View.VISIBLE);
                }
                if (ambulance3 != null) {
                    ambulance3.setText(request3.getDisplayText() != null ? request3.getDisplayText() : "Emergency Response Unit");
                    ambulance3.setVisibility(View.VISIBLE);
                }
                if (time3 != null) {
                    time3.setText(request3.getTimestamp() != null ? request3.getTimestamp() : "Oct 15, 2025 - 2:30 PM");
                    time3.setVisibility(View.VISIBLE);
                }
                if (status3 != null) {
                    status3.setText(request3.getStatus() != null ? request3.getStatus() : "Cancelled");
                    status3.setVisibility(View.VISIBLE);
                }
            }
            
            // Fourth request
            if (requests.size() > 3) {
                Request request4 = requests.get(3);
                TextView emergency4 = findViewById(R.id.txt_stroke_emergency);
                TextView ambulance4 = findViewById(R.id.txt_lifesaver_ambulance);
                TextView time4 = findViewById(R.id.txt_sep_20_pm);
                TextView status4 = findViewById(R.id.txt_completed2);
                
                // Show fourth entry elements and backgrounds
                showFourthEntryElements(request4);
                
                if (emergency4 != null) {
                    emergency4.setText(request4.getEmergencyType() != null ? request4.getEmergencyType() : "Stroke Emergency");
                    emergency4.setVisibility(View.VISIBLE);
                }
                if (ambulance4 != null) {
                    ambulance4.setText(request4.getDisplayText() != null ? request4.getDisplayText() : "LifeSaver Ambulance");
                    ambulance4.setVisibility(View.VISIBLE);
                }
                if (time4 != null) {
                    time4.setText(request4.getTimestamp() != null ? request4.getTimestamp() : "Sep 28, 2025 - 3:20 PM");
                    time4.setVisibility(View.VISIBLE);
                }
                if (status4 != null) {
                    status4.setText(request4.getStatus() != null ? request4.getStatus() : "Completed");
                    status4.setVisibility(View.VISIBLE);
                }
            }
            
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error updating original TextViews", e);
        }
    }
    
    // Show first entry background elements
    private void showFirstEntryElements(Request request) {
        try {
            ImageView bg1 = findViewById(R.id.img_rectangle1);
            ImageView bg2 = findViewById(R.id.img_rectangle5);
            ImageView statusBg = findViewById(R.id.img_rectangle9);
            
            if (bg1 != null) bg1.setVisibility(View.VISIBLE);
            if (bg2 != null) bg2.setVisibility(View.VISIBLE);
            if (statusBg != null) statusBg.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error showing first entry elements", e);
        }
    }
    
    // Show second entry background elements
    private void showSecondEntryElements(Request request) {
        try {
            ImageView bg1 = findViewById(R.id.img_rectangle2);
            ImageView bg2 = findViewById(R.id.img_rectangle6);
            ImageView statusBg = findViewById(R.id.img_rectangle10);
            
            if (bg1 != null) bg1.setVisibility(View.VISIBLE);
            if (bg2 != null) bg2.setVisibility(View.VISIBLE);
            if (statusBg != null) statusBg.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error showing second entry elements", e);
        }
    }
    
    // Show third entry background elements
    private void showThirdEntryElements(Request request) {
        try {
            ImageView bg1 = findViewById(R.id.img_rectangle3);
            ImageView bg2 = findViewById(R.id.img_rectangle7);
            ImageView statusBg = findViewById(R.id.img_rectangle11);
            
            if (bg1 != null) bg1.setVisibility(View.VISIBLE);
            if (bg2 != null) bg2.setVisibility(View.VISIBLE);
            if (statusBg != null) statusBg.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error showing third entry elements", e);
        }
    }
    
    // Show fourth entry background elements
    private void showFourthEntryElements(Request request) {
        try {
            ImageView bg1 = findViewById(R.id.img_rectangle4);
            ImageView bg2 = findViewById(R.id.img_rectangle8);
            ImageView statusBg = findViewById(R.id.img_rectangle12);
            
            if (bg1 != null) bg1.setVisibility(View.VISIBLE);
            if (bg2 != null) bg2.setVisibility(View.VISIBLE);
            if (statusBg != null) statusBg.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error showing fourth entry elements", e);
        }
    }
    
    // Clear original TextViews
    private void clearOriginalTextViews() {
        try {
            // Clear first entry
            TextView emergency1 = findViewById(R.id.txt_heart_attack);
            TextView ambulance1 = findViewById(R.id.txt_city_hospital_ambulance);
            TextView time1 = findViewById(R.id.txt_oct_30_pm_1);
            TextView status1 = findViewById(R.id.txt_completed);
            
            if (emergency1 != null) emergency1.setText("");
            if (ambulance1 != null) ambulance1.setText("");
            if (time1 != null) time1.setText("");
            if (status1 != null) status1.setText("");
            
            // Hide first entry backgrounds
            hideFirstEntryElements();
            
            // Clear second entry
            TextView emergency2 = findViewById(R.id.txt_road_accident);
            TextView ambulance2 = findViewById(R.id.txt_city_hospital_ambulance1);
            TextView time2 = findViewById(R.id.txt_oct_30_pm_2);
            TextView status2 = findViewById(R.id.txt_completed1);
            
            if (emergency2 != null) emergency2.setText("");
            if (ambulance2 != null) ambulance2.setText("");
            if (time2 != null) time2.setText("");
            if (status2 != null) status2.setText("");
            
            // Hide second entry backgrounds
            hideSecondEntryElements();
            
            // Clear third entry
            TextView emergency3 = findViewById(R.id.txt_breathing_problem);
            TextView ambulance3 = findViewById(R.id.txt_emergency_response_unit);
            TextView time3 = findViewById(R.id.txt_oct_30_pm_3);
            TextView status3 = findViewById(R.id.txt_cancelled);
            
            if (emergency3 != null) emergency3.setText("");
            if (ambulance3 != null) ambulance3.setText("");
            if (time3 != null) time3.setText("");
            if (status3 != null) status3.setText("");
            
            // Hide third entry backgrounds
            hideThirdEntryElements();
            
            // Clear fourth entry
            TextView emergency4 = findViewById(R.id.txt_stroke_emergency);
            TextView ambulance4 = findViewById(R.id.txt_lifesaver_ambulance);
            TextView time4 = findViewById(R.id.txt_sep_20_pm);
            TextView status4 = findViewById(R.id.txt_completed2);
            
            if (emergency4 != null) emergency4.setText("");
            if (ambulance4 != null) ambulance4.setText("");
            if (time4 != null) time4.setText("");
            if (status4 != null) status4.setText("");
            
            // Hide fourth entry backgrounds
            hideFourthEntryElements();
            
            android.util.Log.d("RequestHistory", "Cleared all original TextViews and backgrounds");
            
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error clearing TextViews", e);
        }
    }
    
    // Hide first entry background elements
    private void hideFirstEntryElements() {
        try {
            ImageView bg1 = findViewById(R.id.img_rectangle1);
            ImageView bg2 = findViewById(R.id.img_rectangle5);
            ImageView statusBg = findViewById(R.id.img_rectangle9);
            TextView emergency1 = findViewById(R.id.txt_heart_attack);
            TextView ambulance1 = findViewById(R.id.txt_city_hospital_ambulance);
            TextView time1 = findViewById(R.id.txt_oct_30_pm_1);
            TextView status1 = findViewById(R.id.txt_completed);
            
            if (bg1 != null) bg1.setVisibility(View.GONE);
            if (bg2 != null) bg2.setVisibility(View.GONE);
            if (statusBg != null) statusBg.setVisibility(View.GONE);
            if (emergency1 != null) emergency1.setVisibility(View.GONE);
            if (ambulance1 != null) ambulance1.setVisibility(View.GONE);
            if (time1 != null) time1.setVisibility(View.GONE);
            if (status1 != null) status1.setVisibility(View.GONE);
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error hiding first entry elements", e);
        }
    }
    
    // Hide second entry background elements
    private void hideSecondEntryElements() {
        try {
            ImageView bg1 = findViewById(R.id.img_rectangle2);
            ImageView bg2 = findViewById(R.id.img_rectangle6);
            ImageView statusBg = findViewById(R.id.img_rectangle10);
            TextView emergency2 = findViewById(R.id.txt_road_accident);
            TextView ambulance2 = findViewById(R.id.txt_city_hospital_ambulance1);
            TextView time2 = findViewById(R.id.txt_oct_30_pm_2);
            TextView status2 = findViewById(R.id.txt_completed1);
            
            if (bg1 != null) bg1.setVisibility(View.GONE);
            if (bg2 != null) bg2.setVisibility(View.GONE);
            if (statusBg != null) statusBg.setVisibility(View.GONE);
            if (emergency2 != null) emergency2.setVisibility(View.GONE);
            if (ambulance2 != null) ambulance2.setVisibility(View.GONE);
            if (time2 != null) time2.setVisibility(View.GONE);
            if (status2 != null) status2.setVisibility(View.GONE);
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error hiding second entry elements", e);
        }
    }
    
    // Hide third entry background elements
    private void hideThirdEntryElements() {
        try {
            ImageView bg1 = findViewById(R.id.img_rectangle3);
            ImageView bg2 = findViewById(R.id.img_rectangle7);
            ImageView statusBg = findViewById(R.id.img_rectangle11);
            TextView emergency3 = findViewById(R.id.txt_breathing_problem);
            TextView ambulance3 = findViewById(R.id.txt_emergency_response_unit);
            TextView time3 = findViewById(R.id.txt_oct_30_pm_3);
            TextView status3 = findViewById(R.id.txt_cancelled);
            
            if (bg1 != null) bg1.setVisibility(View.GONE);
            if (bg2 != null) bg2.setVisibility(View.GONE);
            if (statusBg != null) statusBg.setVisibility(View.GONE);
            if (emergency3 != null) emergency3.setVisibility(View.GONE);
            if (ambulance3 != null) ambulance3.setVisibility(View.GONE);
            if (time3 != null) time3.setVisibility(View.GONE);
            if (status3 != null) status3.setVisibility(View.GONE);
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error hiding third entry elements", e);
        }
    }
    
    // Hide fourth entry background elements
    private void hideFourthEntryElements() {
        try {
            ImageView bg1 = findViewById(R.id.img_rectangle4);
            ImageView bg2 = findViewById(R.id.img_rectangle8);
            ImageView statusBg = findViewById(R.id.img_rectangle12);
            TextView emergency4 = findViewById(R.id.txt_stroke_emergency);
            TextView ambulance4 = findViewById(R.id.txt_lifesaver_ambulance);
            TextView time4 = findViewById(R.id.txt_sep_20_pm);
            TextView status4 = findViewById(R.id.txt_completed2);
            
            if (bg1 != null) bg1.setVisibility(View.GONE);
            if (bg2 != null) bg2.setVisibility(View.GONE);
            if (statusBg != null) statusBg.setVisibility(View.GONE);
            if (emergency4 != null) emergency4.setVisibility(View.GONE);
            if (ambulance4 != null) ambulance4.setVisibility(View.GONE);
            if (time4 != null) time4.setVisibility(View.GONE);
            if (status4 != null) status4.setVisibility(View.GONE);
        } catch (Exception e) {
            android.util.Log.e("RequestHistory", "Error hiding fourth entry elements", e);
        }
    }
}